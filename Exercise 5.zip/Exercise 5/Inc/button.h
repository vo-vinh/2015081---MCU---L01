/*
 * button.h
 *
 *  Created on: Sep 27, 2022
 *      Author: admin
 */

#ifndef INC_BUTTON_H_
#define INC_BUTTON_H_

#include "main.h"

#define NORMAL_STATE SET
#define PRESSED_STATE RESET


void getKeyInput();



#endif /* INC_BUTTON_H_ */
